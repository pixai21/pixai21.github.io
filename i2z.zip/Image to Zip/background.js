chrome.runtime.onInstalled.addListener(() => {
    console.log('i');
    chrome.storage.local.clear();
    chrome.contextMenus.create({ title: '写真を取得', contexts: ['image'], id: 'parent' })
});
chrome.action.onClicked.addListener(() => chrome.tabs.query({ active: true, currentWindow: true }, tabs => chrome.tabs.sendMessage(tabs[0].id, { action: "a" })));
chrome.contextMenus.onClicked.addListener((info) => chrome.tabs.query({ active: true, currentWindow: true }, tabs => chrome.tabs.sendMessage(tabs[0].id, { action: "cm", data: info.srcUrl })));
chrome.runtime.onMessage.addListener((m) => {
    switch (m.action) {
        case 'get':
            chrome.storage.local.get(["data"], (d) => {
                if (d.data && d.data.ended == 'false') {
                    chrome.storage.local.set({ "data": { name: d.data.name, lc: d.data.lc, ended: 'true' } });
                    chrome.tabs.query({ active: true, currentWindow: true }, tabs => chrome.tabs.sendMessage(tabs[0].id, { action: 'endGet', data: d.data }));
                }
            });
            break;
        case 'setLocal':
            chrome.storage.local.set({ "data": { name: m.data.name, lc: m.data.lc, ended: 'false' } });
            //console.log(decodeURIComponent(m.action.slice(m.action.search(/[&?]abekenman=/) + 11, m.action.indexOf('&', m.action.search(/[&?]abekenman=/) + 11))));
            chrome.tabs.query({ active: true, currentWindow: true }, tabs => chrome.tabs.sendMessage(tabs[0].id, { action: 'endSetLocal', data: m.data.lc[0] }));
            break;
    }
});
//.then(() => chrome.contextMenus.create({ title: '写真を取得', contexts: ['image'], id: 'parent' }));