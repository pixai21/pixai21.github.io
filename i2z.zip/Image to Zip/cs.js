console.log('Image to Zip');
async function cpo(n, dl) {
  try {
    let ae = document.createElement('a');
    ae.download = n + '.zip';
    const zip = new JSZip();
    for (let i = 0; i < dl.length; i++) {
      zip.file(('0'.repeat((dl.length - 1).toString().length - i.toString().length)) + i + '.' + (dl[i].type.slice(dl[i].type.indexOf('/') + 1)), dl[i]);
    }
    ae.href = URL.createObjectURL(await zip.generateAsync({ type: "blob" }));
    document.addEventListener('click', () => ae.click());
    alert('Fin.');
  } catch (error) {
    alert(error);
  }
}
function iesg(n, a, i, ba) {
  console.log(i);
  fetch(a[i]).then(res => res.blob()).then(b => {
    ba.push(b);
    if (i < a.length - 1) iesg(n, a, i + 1, ba);
    else {
      console.log('cpo');
      cpo(n, ba);
    }
  }).catch(ero => console.log(ero));
}
function col(age) {
  let ies = [];
  function gies(cn) {
    return (cn.parentNode.querySelectorAll('img[src]').length <= 1 ? gies(cn.parentNode) : ((!confirm('ダウンロードしたいのは、' + cn.parentNode.querySelectorAll('img[src]').length + '枚くらいかそれ以下の枚数、の写真ですか？')) ? gies(cn.parentNode) : cn.parentNode.querySelectorAll('img[src]')));
  }
  const pn = gies(age.target);
  const pnpw = pn[0].width;
  for (let iies = 0; iies < pn.length; iies++) {
    if (pnpw == pn[iies].width) ies[iies] = (pn[iies].dataset.big ?? pn[iies].dataset.src ?? (pn[iies].parentNode.href ?? pn[iies].src));
    else break;
  }
  console.log(ies.join('\n'));
  if (location.origin != new URL(ies[0]).origin) chrome.runtime.sendMessage({ action: 'setLocal', data: { name: (document.getElementsByClassName('title').length == 1 ? document.querySelector('.title').innerText : (document.querySelector('h1') ? document.querySelector('h1').innerText : document.title)), lc: ies } });
  else iesg(document.getElementsByClassName('title').length == 1 ? document.querySelector('.title').innerText : (document.querySelector('h1') ? document.querySelector('h1').innerText : document.title), ies, 0, []);
}
function start() {
  console.log(location.origin);
  chrome.runtime.onMessage.addListener((m) => {
    switch (m.action) {
      case 'a':
        console.log("a");
        document.oncontextmenu = e => col(e);
        break;
      case 'endSetLocal':
        console.log('endSetLocal');
        location.assign(m.data);
        break;
      case 'endGet':
        console.log('endGet');
        iesg(m.data.name, m.data.lc, 0, []);
        break;
    }
  });
  chrome.runtime.sendMessage({ action: 'get' });
  let age = null;
  let ge = (m) => {
    if (m.action == "cm") {
      console.log("cm");
      col(age);
    }
  }
  document.addEventListener('contextmenu', e => {
    age = e;
    if (chrome.runtime.onMessage.hasListener(ge)) chrome.runtime.onMessage.removeListener(ge);
    chrome.runtime.onMessage.addListener(ge);
  });
}
onload = () => start();