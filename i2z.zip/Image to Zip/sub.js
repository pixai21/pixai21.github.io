if (location.origin.search(/((google[.]co)|(mozilla[.]org))/) == -1) {
    (function () {
        let abekenman_cel = 0;
        let abekenman_mo = new MutationObserver(() => {
            console.log('abekenman_mo');
            if (abekenman_cel < document.getElementsByTagName('canvas').length) for (const ce of document.getElementsByTagName('canvas')) (!ce.abekenman) || abekenman_cf(ce);
        });
        let abekenman_i = [];
        function abekenman_cf(e) {
            abekenman_cel++;
            console.log('Canvas');
            e.abekenman = true;
            const di = e.getContext('2d').drawImage.bind(e.getContext('2d'));
            e.getContext('2d').drawImage = (ab1, ab2, ab3, ab4, ab5, ab6, ab7, ab8, ab9) => (!di(abekenman_i[abekenman_i.length - 1] = ab1, ab2, ab3, ab4, ab5, ab6, ab7, ab8, ab9) || console.log(abekenman_i));
        }
        let abekenman_ended = false;
        const ABEKENMAN_DCE = document.createElement.bind(document);
        document.createElement = (tn, o) => {
            const e = ABEKENMAN_DCE(tn, o);
            console.log('onCreateElement: ' + e.tagName);
            if (e.tagName == 'CANVAS') abekenman_cf(e);
            return e;
        };
        const ABEKENMAN_DAEL = document.addEventListener.bind(document);
        function abekenman_start() {
            let hcec = document.getElementsByTagName('canvas');
            const hcecl = hcec.length;
            console.log(hcecl);
            for (let i = 0; i < hcecl; i++) abekenman_cf(hcec[i]);
            abekenman_mo.observe(document.body, { subtree: true, childList: true })
            abekenman_ended = true;
        }
        document.addEventListener = function abekenman_ael(t, l) {
            console.log('onAddEventListener');
            if (!abekenman_ended) ABEKENMAN_DAEL('DOMContentLoaded', () => abekenman_ael(t, l));
            else ABEKENMAN_DAEL(t, l);
        }
        ABEKENMAN_DAEL('DOMContentLoaded', () => abekenman_start());
    })();
}